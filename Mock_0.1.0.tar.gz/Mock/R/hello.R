myFun <- function(arg1){
  5*arg1+1
}
myFun2 <- function(){
  names(genomeStyles())
}
